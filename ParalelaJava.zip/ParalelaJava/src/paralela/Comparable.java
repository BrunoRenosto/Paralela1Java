package paralela;

public interface Comparable {
	
	Double compareTo(T outro);

}
